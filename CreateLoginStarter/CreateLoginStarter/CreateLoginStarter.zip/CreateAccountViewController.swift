//
//  CreateAccountViewController.swift
//  CreateLoginStarter
//
//  Created by Roux-Dufault, Danny on 2017-04-13.
//  Copyright © 2017 Chris. All rights reserved.
//

import UIKit

class CreateAccountViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet var username: UITextField!
    @IBOutlet var email: UITextField!
    @IBOutlet var password: UITextField!
    @IBOutlet var verifyPassword: UITextField!
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    
    
    
    @IBAction func AccountSubmit(_ sender: UIButton)
    {
        /*let alertController = UIAlertController(title: "Error", message: "aaaaaa", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alertController, animated: true, completion: nil)*/
        if validateFields()
        {
            addAccount()
        }
    }
}



//methods
extension CreateAccountViewController
{
    func usernameValid(username:String) -> Bool
    {
        do {
            let regex = try NSRegularExpression(pattern: "^[a-zA-Z0-9!@#$%^&*'\"?]{5,}$")
            return regex.firstMatch(in: username, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, username.characters.count)) != nil
        } catch {
            return false
        }
    }
    
    func emailValid(email:String) -> Bool
    {
        do {
            let regex = try NSRegularExpression(pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}")
            return regex.firstMatch(in: email, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, email.characters.count)) != nil
        } catch {
            return false
        }
    }
    
    func passwordValid(password:String) -> Bool
    {
        do {
            let regex = try NSRegularExpression(pattern: "^[a-zA-Z0-9!@#$%^&*'\"?]{5,}$")
            return regex.firstMatch(in: password, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, password.characters.count)) != nil
        } catch {
            return false
        }
    }
    
    
    
    func validateFields() -> Bool
    {
        let usernameValue = self.username.text
        let emailValue = self.email.text
        let passwordValue = self.password.text
        let verifyPasswordValue = self.verifyPassword.text
        
        var missingFields = [String]()
        if usernameValue == ""
        {
            missingFields.append("Username")
        }
        
        if emailValue == ""
        {
            missingFields.append("Email")
        }
        
        if passwordValue == ""
        {
            missingFields.append("Password")
        }
        
        if verifyPasswordValue == ""
        {
            missingFields.append("Verify Password")
        }
        
        if missingFields.count > 0
        {
            let alertValue = "Do not leave the following field(s) blank: \(missingFields.joined(separator: ", "))"
            //do an alert
            UIAlertController.showErrorAlert(message: alertValue, sender: self)
            return false
        }
        
        if passwordValue != verifyPasswordValue
        {
            let alertValue = "Passwords do not match"
            //do an alert
            UIAlertController.showErrorAlert(message: alertValue, sender: self)
            return false
        }
        
        
        
        var invalidFields = [String]()
        
        if !usernameValid(username: usernameValue!)
        {
            invalidFields.append("Username")
        }
        
        if !emailValid(email: emailValue!)
        {
            invalidFields.append("Email")
        }
        
        if !passwordValid(password: passwordValue!)
        {
            invalidFields.append("Password")
        }
        
        if invalidFields.count > 0
        {
            let alertValue = "The following field(s) are not in the correct format: \(invalidFields.joined(separator: ", "))"
            UIAlertController.showErrorAlert(message: alertValue, sender: self)
            //do the alert
            return false
        }
        
        
        return true
    }
    
    func addAccount()
    {
        let usernameValue = self.username.text
        let emailValue = self.email.text
        let passwordValue = self.password.text
        
        var data = [String:String]()
        data["username"] = usernameValue
        data["password"] = passwordValue
        data["email"] = emailValue
        
        URLRequest.getRequestResult(url: APIDetails.buildUrl(callType: .addUser, params: []), requestMethod: "POST", dataToSend: data)
        {
            (success, message, result) in
            
            //join back the main thread
            DispatchQueue.main.async(execute: {
                () -> Void in
                if success
                {
                    self.dismiss(animated: true, completion: nil)
                }else
                {
                    UIAlertController.showErrorAlert(message: message, sender: self)
                }
            })
            
            
        }
    }
}



















